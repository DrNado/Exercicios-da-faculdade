#include "Video.h"

  Video::Video()
  {
    
  }
	Video::Video(string novoNome)
	{
		nome = novoNome;
		cout << "VIDEO " << nome << " CADASTRADO COM SUCESSO" << endl;
	}	
	Video::~Video()
	{
		
	}
	void Video::play()
	{
		cout << "PLAY video " << nome << endl;
	}
	string Video::getNome()
	{
		return nome;
	}

