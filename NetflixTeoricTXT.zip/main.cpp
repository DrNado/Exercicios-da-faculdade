#include "Video.h"

class Preferencias
{
	string historico[10];
	int qtdFilmes;
public:
	Preferencias(): qtdFilmes(0)
	{
		
	}	
	~Preferencias()
	{
		
	}
	void setFilmeAssistido(string nomeFilme)
	{
		historico[qtdFilmes] = nomeFilme;
		cout << "Filme " << nomeFilme << " adicionado ao historico!" << endl;
	}
};

class Cliente
{
private:
	string nome;
	string senha;
	Preferencias *pref;
	Video *videoEscolhido;
public:
	Cliente(){
		pref = new Preferencias();
		cout << "Cliente criado com sucesso!" << endl;
	}	
	~Cliente()
	{
		
	}
	
	void listarFilmes(Video listaVideos[])
	{
		int filmeEscolhido;
		do{
			cout << "Selecione o filme:" << endl;
			for(int i = 0; i < 3; i++)
			{
				cout << i << " - " << listaVideos[i].getNome() << endl;
			}			
			
			cin >> filmeEscolhido;
		
			if(filmeEscolhido >= 3 || filmeEscolhido < 0)
			{
				cout << "Filme invalido" << endl;
			}
		}while(filmeEscolhido >= 3 || filmeEscolhido < 0);
		
		videoEscolhido = &listaVideos[filmeEscolhido];
		assistir();
		
	}
	
	void setNome(string novoNome)
	{
		nome = novoNome;
		cout << "Nome " << nome << " atribuido com sucesso!" << endl;
	}
	
	string getNome()
	{
		return nome;
	}
	
	void setSenha(string novaSenha)
	{
		senha = novaSenha;
	}
	
	string getSenha()
	{
		return senha;
	}
	
	Preferencias* getPreferencias()
	{
		return pref;
	}
	
	void assistir()
	{
		videoEscolhido->play();
	//	pref->setFilmeAssistido(videoEscolhido->getNome());	
	}
};

class Sistema
{
	Cliente *clientes[2];
	int qtdClientes;

	Preferencias *preferenciasSistema[2];
	
	Video listaVideos[3];
	int qtdFilmes;
	
public:
	Sistema(): qtdClientes(0), qtdFilmes(0)
	{
		
	}	
	~Sistema()
	{
		for(int i = 0; i < 2; i++)
		{
			delete clientes[i];
			delete preferenciasSistema[i];
		}
	}
	
	void CadastrarClientes()
	{
		if(qtdClientes < 2)
		{
			clientes[qtdClientes] = new Cliente();
			
			cout << "Digite o nome do cliente:";
			string nome;
			cin >> nome;
			clientes[qtdClientes]->setNome(nome);

			cout << "Digite a senha de " << nome << ": ";
			string senha;
			cin >> senha;
			clientes[qtdClientes]->setSenha(senha);
			
			
			preferenciasSistema[qtdClientes] = clientes[qtdClientes]->getPreferencias();
			
			qtdClientes++;
		}
		else
		{
			cout << "Erro ao cadastrar cliente!" << endl;
		}
	}
	
	void CadastrarFilme()
	{
		if(qtdFilmes < 3)
		{
			cout << "Digite o nome do filme: ";
			string nome;
			cin >> nome;
			
			listaVideos[qtdFilmes] = Video(nome);
			qtdFilmes++;
		}
		else
		{
			cout << "Limite de filmes alcan�ado!" << endl;
		}
	}
	
	void run()
	{
		int opcao;
		do{
			cout << "MENU NETFLIX" << endl;
			cout << "0 - Sair" << endl;
			cout << "1 - Cadastrar Clientes" << endl; 
			cout << "2 - Cadastrar Filmes" << endl;
			cout << "3 - Login" << endl;
			cin >> opcao;
			
			switch(opcao)
			{
				case 0:
					cout << "SAIR DO SISTEMA" << endl;
					break;
				case 1:
					CadastrarClientes();
					break;
				case 2:
					CadastrarFilme();
					break;
				case 3:
					cout << "Digite o username:";
					string username;
					cin >> username;
					
					cout << "Digite a senha: ";
					string senha;
					cin >> senha;
					
					login(username, senha);
					break;
			//	default:
			//		cout << "Opcao invalida!" << endl;
			}
		}
		while(opcao != 0);
	}
	
	void login(string username, string senha)
	{
		for(int i = 0; i < qtdClientes; i++)
		{
			if(clientes[i]->getNome() == username)
			{
				if(clientes[i]->getSenha() == senha)
				{
					cout << username << " foi conectado" << endl;
					clientes[i]->listarFilmes(listaVideos);					
				}
				else
				{
					cout << "Senha invalida" << endl;
				}	
			} 
			else
			{
				cout << "Cliente invalido" << endl;
			}
		}
	}
	
};

int main()
{
	Sistema netflix;
	netflix.run();
	return 0;
}
