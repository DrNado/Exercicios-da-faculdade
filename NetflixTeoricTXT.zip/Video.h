#include <iostream>
#include <string>
using namespace std;

class Video
{
private:
	string nome;
public:
	// Prot�tipo
	Video();
	Video(string novoNome);
	~Video();
	void play();
	string getNome();
};

