#include <iostream>
#include <queue>
using namespace std;

int main()
{
    queue<string> estac;

    char escolha;
    string placa;
    bool igual = false;

    cout << "Informe a placa do carro: \n";
    cin >> placa;
    estac.push(placa);
    cout << "Identificador " << placa << " adicionado ao final da fila. ";
    cout << estac.size() << " carros estacionados.\n\n";

    do
    {
        cout << "A: adicionar carros\nB: retirar carros\nC: sair\nS: ver estacionamento\n";
        cin >> escolha;
        switch (escolha)
        {
        case 'a':
            cout << "Informe a placa do carro a ser adicionado: \n";
            cin >> placa;
            estac.push(placa); //conferir se não é igual a outeo
            cout << "Identificador " << placa << " adicionado ao final da fila. ";
            cout << estac.size() << " carros estacionados.\n";
            system("pause");
            system("cls");
            break;
        case 'b':
            cout << "Informe a placa do carro a ser retirado: \n";
            cin >> placa;
            for (int i = 0; i < estac.size(); i++) {
                if (placa == estac.front()) {
                    igual = true;
                    break;
                }

            }
            if (igual == true) {
                do
                {
                    estac.push(estac.front());
                    estac.pop();

                } while (placa != estac.front());

                estac.pop();
                system("pause");
                system("cls");
            }
            else
            {
                cout << "Placa nao encontrada.\n";
                system("pause");
                system("cls");
            }
        case 's':

            cout << "Placas estacionadas: \n << ";
            for (int i = 0; i < estac.size(); i++) {
            }
            cout << estac.front() << endl;
            break;
        default:
            cout << "Op inválida.\n";
            system("pause");
            system("cls");
            break;
        }
    } while (escolha != 'c');

    return 0;
}