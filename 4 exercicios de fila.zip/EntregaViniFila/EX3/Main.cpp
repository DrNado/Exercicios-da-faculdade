#include "Paciente.h"

//struct pacs
//{
//	queue<int> pr5;
//	queue<int> pr4;
//	queue<int> pr3;
//	queue<int> pr2;
//	queue<int> pr1;
//};


void montafila(Paciente &q,queue<Paciente> &espera, priority_queue<int> &Ftrans)
{
	
			if (q.getprior() == Ftrans.top())
			{
				espera.push(q);
				Ftrans.pop();
			}

	
	
}
void mostraPacDaOperacao(queue<Paciente>& espera)
{
	int imput;
	
		cout << "o paciente " << espera.front().getnome() << " a prioridade eh " << espera.front().getprior() << endl;

		cout << "esta se encaminhando pra cirurgia" << endl;

		cout << "gostaria de ver quantos pacientes estao esperando? 1/s" << endl;

		cin >> imput;
		if (imput == 1)
		{
			cout << "existem " << espera.size() << " pacientes na fila " << endl;
		}
		espera.pop();
	
	


	
}



void main()
{
	/*pacs filaprior;*/
	queue<Paciente> espera;
	priority_queue<int> Ftransplant;
	srand(time(NULL));
	
	//int pr = rand()% 5 + 1 ;



	Paciente pac1("marcos", 3, (int)rand() % 5 + 1);
	Ftransplant.push(pac1.getprior());
	Paciente pac2("vini", 2, (int)rand() % 5 + 1);
	Ftransplant.push(pac2.getprior());
	Paciente pac3("matt", 8, (int)rand() % 5 + 1);
	Ftransplant.push(pac3.getprior());
	Paciente pac4("bruno", 5, (int)rand() % 5 + 1);
	Ftransplant.push(pac4.getprior());



	while (!Ftransplant.empty())
	{
		montafila(pac1, espera, Ftransplant);
		montafila(pac2, espera, Ftransplant);
		montafila(pac3, espera, Ftransplant);
		montafila(pac4, espera, Ftransplant);
	}
	while (!espera.empty())
	{
		mostraPacDaOperacao(espera);
	}
	system("pause");
}