#include "Paciente.h"
Paciente::Paciente(string nom, int tele,int pr)
{
	nome = nom;
	tel = tele;
	prior = pr;
}

int Paciente:: getprior()
{
	return prior;
}
string Paciente::getnome()
{
	return nome;
}