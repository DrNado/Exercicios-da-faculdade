#pragma once
#include<iostream>
#include<queue>
#include <ctime>  
#include<string>
using namespace std;
class Paciente
{
	string nome;
	int tel;
	int prior;
	
public:
	

	Paciente(string nom, int tele, int pr);

	int getprior();
	string getnome();
	
};

