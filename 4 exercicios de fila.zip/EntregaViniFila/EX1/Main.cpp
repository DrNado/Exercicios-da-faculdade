#include<iostream>
#include<queue>
#include<ctime>
using namespace std;


	queue<float>Caixa[5];

	float numOfminutes = 0;
	float minutesPassed = 0;
	float totalClients = 0;
	float timeDifclients = 0;

	int AchaMenor()
	{
		int contCaixa = 0;
		int temp = Caixa[contCaixa].size();

		for (int i = 1; i < 5; i++)
		{

			if (Caixa[i].size() < temp)
			{
				temp = Caixa[i].size();
				contCaixa = i;
			}
		}
		return contCaixa;
	}
	void AtendeClientes()
	{
		for (int i = 0; i < 5; i++)
		{
			int rnd = rand() % 2 + 1;


			for (int j = 0; j < rnd; j++)
			{
				if (Caixa[i].size() > 0)
				{
					float tempTime = rand() % 60;
					tempTime += minutesPassed * 60;
					//cout << tempTime << " " << Caixa[i].front() << endl;
					while (tempTime < Caixa[i].front())
					{
						tempTime = rand() % 60;
						tempTime += minutesPassed * 60;
					}

					timeDifclients += (tempTime - Caixa[i].front());
					Caixa[i].pop();
				}
			}
		}


	}


	void ChegaClientes()
	{
		int rnd = rand() % 13 + 4;
		int contCaixa = AchaMenor();

		
		totalClients += rnd;
		for (int i = 0; i < rnd; i++)
		{
			Caixa[contCaixa].push(rand()% 60 + (minutesPassed * 60));
			int contCaixa = AchaMenor();
		}
		AtendeClientes();
	}



void main()
{
	srand(time(NULL));

	cout << "digite o num de minutos: " << endl;

	cin >> numOfminutes;

	for (int i = 0; i < numOfminutes; i++)
	{
		ChegaClientes();
		minutesPassed++;
	}
	while (Caixa[0].size() > 0 && Caixa[1].size() > 0 && Caixa[2].size() > 0 && Caixa[3].size() > 0 && Caixa[4].size() > 0)
	{
		AtendeClientes();
		minutesPassed++;

	}

	cout << "tempo medio: " << timeDifclients / totalClients<<"s " << endl;
	system("pause");
}
