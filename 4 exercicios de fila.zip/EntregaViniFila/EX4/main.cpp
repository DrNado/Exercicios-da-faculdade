#include<iostream>
#include<queue>
#include<ctime>
using namespace std;

priority_queue<int>fila;



void main()
{
	srand(time(NULL));
	while (true)
	{
		int iteracoes = rand() % 20 + 1;

		for (int i = 0; i < iteracoes; i++)
		{
			fila.push(rand() % 9);
		}
		while (!fila.empty())
		{

			switch (fila.top())
			{
			case 8:
				cout << "Colisao" << endl;
				fila.pop();
				break;
			case 7:
				cout << "Atualizacao da tela" << endl;
				fila.pop();
				break;
			case 6:
				cout << "Particulas" << endl;
				fila.pop();
				break;
			case 5:
				cout << "Logica do jogo" << endl;
				fila.pop();
				break;
			case 4:
				cout << "Inteligencia Artificial" << endl;
				fila.pop();
				break;
			case 3:
				cout << "Simulacao Fisica" << endl;
				fila.pop();
				break;
			case 2:
				cout << "Teclado" << endl;
				fila.pop();
				break;
			case 1:
				cout << "Mouse" << endl;
				fila.pop();
				break;
			case 0:
				cout << "Internet" << endl;
				fila.pop();
				break;

			default:
				break;
			}
		}

		
		system("pause");

		cout << "" << endl;
		cout << "" << endl;

	}
	
}


